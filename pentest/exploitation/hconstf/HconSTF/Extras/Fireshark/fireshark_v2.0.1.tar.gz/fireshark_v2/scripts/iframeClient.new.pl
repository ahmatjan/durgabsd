#!/usr/bin/perl -w

use Getopt::Std;

use warnings;
use strict;
use URI;
use IO::Socket;
use JSON::XS;
use MIME::Base64;
use GraphViz;
use Time::HiRes qw(time gettimeofday tv_interval);
use Data::Dump qw(dump);
use File::stat;
use HTML::TreeBuilder;

#
# Globals
#
use vars qw/ %opt /;

my %nv;

sub IncrementNV
{
    my $n = shift;
    if($nv{$n})
    {
        $nv{$n}++;
    }
    else
    {
        $nv{$n} = 1;
    }
}

sub hashValueAscendingNum {
   $nv{$a} <=> $nv{$b};
}

sub hashValueDescendingNum {
    $nv{$b} <=> $nv{$a};
}

#
# Command line options processing
#
sub init()
{
    my $opt_string = 'hvde:';
    getopts( "$opt_string", \%opt ) or usage();
    if($opt{h} or !$opt{e})
    {
        usage();
    }
}

#
# Message about this program and how to use it
#
sub usage()
{
print STDERR << "EOF";

    This program will take an input file of event data and output
    a iframes and obfuscated iframes 

    usage: $0 [-hvd] [-e file]

     -h        : this (help) message
     -v        : verbose output
     -d        : print debugging messages to stderr
     -e file   : event data input file 

    example: $0 -v -d -e file

EOF

    exit;
}

init();

print STDERR "Verbose mode ON.\n" if $opt{v};
print STDERR "Debugging mode ON.\n" if $opt{d};

my $event_input_file;

if($opt{e})
{
    $event_input_file = $opt{e}; 
    print "event input file = $event_input_file \n" if $opt{v} || $opt{d};
}
else
{
    exit;
}

if($opt{e})
{
    open EVENTS, "<", $event_input_file or die $!;
}

##############################################################

my $str;
my $events;
my @urls;
my $json = JSON::XS->new;

if($opt{e}) {
    $str = do { local $/; <EVENTS> };
    eval { $events = $json->decode($str); };
    close EVENTS;

} else {
    exit;
}

my $g_iframes = {};
foreach my $event (@{$events}) {

    if(defined $event->{eventType} && $event->{eventType} eq "loadurl") {
        print "type: " . $event->{eventType} . "\n";
    } 
    if(defined $event->{eventType} && $event->{eventType} eq "loadurl") {
        print "url: " . $event->{url} . "\n";
    } 
    if(defined $event->{eventType} && $event->{eventType} eq "contentloaded") {
        buildChildTree($event->{doms}, "", "");
    } 

}

sub get_file_contents {

    my $filepath = shift @_;

    my $offset = 0;
    open FILE, "$filepath" or die print $!;
    binmode FILE;
    my ($buf, $data, $n);
    while(($n = read FILE, $data, 4) != 0) {
        $buf .= $data;
        $offset += $n;
    }
    close FILE;

    return $buf;
}

sub buildChildTree {

    my ($domarrayref, $parent_src_payload, $parent_dom_payload) = @_;

    foreach my $dom (@{$domarrayref}) {

        if ($dom->{url} eq "about:blank") { next; }


        #print "$dom->{url} ( $dom->{name} )\n";
        if ($dom->{name} eq "IFRAME") {
            $g_iframes->{$dom->{url}} = $dom->{url};

            # logic:
            # if iframe is alive thus a dom iframe 
            # is present in the DOM BUT not the SRC
	    # then consider malicious
            my $url = $dom->{url};

            if($parent_dom_payload =~ /$url/ and  
	       $parent_src_payload !~ /$url/) {
                    print $url . " is MALICIOUS!! (assumed because of obfuscated iframe)\n";
	    }

        }

        if(defined $dom->{srcfile} && defined $dom->{filepath}) {
            my $src_payload = get_file_contents($dom->{srcfile});
            my $dom_payload = get_file_contents($dom->{filepath});

            # print all iframes
            my $domtree = HTML::TreeBuilder->new;
    	    $domtree->parse($dom_payload);

            my @iframes = $domtree->look_down('_tag' => 'iframe');
	    foreach my $iframe (@iframes) {
                #print "iframe: " . $iframe->as_HTML . "\n";
		if(defined $iframe->attr('src') && length($iframe->attr('src')) > 0) {
                    print "iframe: " . $iframe->attr('src') . "\n";
		}
	    }

            my ($script, @domscripts);

            @domscripts = $domtree->look_down('_tag' => 'script');
	    foreach $script (@domscripts) {
                if(defined $script->attr('src')) {
		    my $url = $script->attr('src');
		    if($url =~ /^http:\/\//ig) {
                        if($src_payload !~ /$url/g) {
			    my $u = URI->new($url);
			    my $host = $u->host;
			    if($host ne "revenue.net" &&
			       $host ne "google.com" &&
			       $host ne "www.google.com" &&
			       $host !~ /cnzz.xom$/ &&
			       $host ne "doubleclick.net") {
			

			       # uncomment if want to see possible scripts
                               #print "dom script: " . $script->attr('src') . "\n";
			    }
		        }
		    }
		}
	    }
	
	    $domtree->eof();

            if($dom->{name} eq "PARENT") {
                $parent_dom_payload = $dom_payload;
                $parent_src_payload = $src_payload;
	    }
        }

        my $n = scalar @{ $dom->{childdoms} };
        if($n > 0) {
            buildChildTree($dom->{childdoms}, $parent_src_payload, $parent_dom_payload);
        }
    }
}

	

#!/bin/sh

# in case fireshark is already running
/etc/init.d/fireshark stop
killall firefox-bin
killall fireshark

# attempt to install xvfb
apt-get install xvfb

# create a fireshark user acount
adduser fireshark

# add fireshark user to sudo file and specify NOPASSWD
echo "fireshark ALL=(ALL)    NOPASSWD:ALL" >> /etc/sudoers

# cp scripts to new fireshark user account home directory
mkdir /home/fireshark/scripts
cp scripts/* /home/fireshark/scripts

# cp home scripts to new fireshark user account home directory
cp home/* /home/fireshark

# create profiles as fireshark user
su fireshark -c "/home/fireshark/manageffprofiles.pl -d"
su fireshark -c "/home/fireshark/manageffprofiles.pl -c"

# change profile permissions
chmod -R 777 /home/fireshark

# create log files
touch /var/log/fireshark.log
chmod 640 /var/log/fireshark.log
chown fireshark:fireshark /var/log/fireshark.log

touch /var/log/fireshark.stdout.log
chmod 640 /var/log/fireshark.stdout.log
chown fireshark:fireshark /var/log/fireshark.stdout.log

touch /var/log/fireshark.stderr.log
chmod 640 /var/log/fireshark.stderr.log
chown fireshark:fireshark /var/log/fireshark.stderr.log

# copy daemon and service
cp daemon/fireshark /usr/sbin/fireshark
cp service/fireshark /etc/init.d/fireshark

# set fireshark service to start on os startup
update-rc.d fireshark defaults

# lastly test to see if it's working
chmod 755 /home/fireshark/testFireshark.pl
/home/fireshark/testFireshark.pl

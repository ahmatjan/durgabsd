#!/usr/bin/perl -w

use Getopt::Std;

use warnings;
use strict;
use URI;
use IO::Socket;
use JSON::XS;
use MIME::Base64;
use GraphViz;
use Fireshark;

#
# Globals
#
use vars qw/ %opt /;

my %nv;

sub IncrementNV
{
    my $n = shift;
    if($nv{$n})
    {
        $nv{$n}++;
    }
    else
    {
        $nv{$n} = 1;
    }
}

sub hashValueAscendingNum {
   $nv{$a} <=> $nv{$b};
}

sub hashValueDescendingNum {
    $nv{$b} <=> $nv{$a};
}

#
# Command line options processing
#
sub init()
{
    my $opt_string = 'hvdu:e:o:';
    getopts( "$opt_string", \%opt ) or usage();
    if($opt{h} or (!$opt{e} and !$opt{u}) or !$opt{o})
    {
        usage();
    }
}

#
# Message about this program and how to use it
#
sub usage()
{
print STDERR << "EOF";

    This program will take an input file of URLs or event data and output
    a GraphViz graph

    usage: $0 [-hvd] [-e file] [-o string]

     -h        : this (help) message
     -v        : verbose output
     -d        : print debugging messages to stderr
     -e file   : event data input file 
     -u file   : URL input file 
     -o string : string to use for output file names 

    example: $0 -v -d -e file -o file

EOF

    exit;
}

init();

print STDERR "Verbose mode ON.\n" if $opt{v};
print STDERR "Debugging mode ON.\n" if $opt{d};

my $event_input_file;
my $url_input_file;
my $output_file_string;

if($opt{u})
{
    $url_input_file = $opt{u};
    print "url input file = $url_input_file \n" if $opt{v} || $opt{d};
}
elsif($opt{e})
{
    $event_input_file = $opt{e}; 
    print "event input file = $event_input_file \n" if $opt{v} || $opt{d};
}
else
{
    exit;
}

if($opt{o})
{
    $output_file_string = $opt{o};
    print "output file string  = $output_file_string \n" if $opt{v} || $opt{d};
}
else 
{
    exit;
}

if($opt{u}) 
{
    open URLS, "<", $url_input_file or die $!;

} elsif($opt{e})
{
    open EVENTS, "<", $event_input_file or die $!;
}

##############################################################

my $str;
my $events;
my $elapsed;
my @urls;
my $json = JSON::XS->new;

my %explicit;
my $use_explicit = 0;

open(XPLICIT, "<xplicit.txt") || die("Could not open file!");
while (<XPLICIT>) {
    my $line = $_;
    chomp($line);
    if($line !~ /^http:/) {
        next;
    } 

    my $u1 = URI->new($line);

    my $host1 = $u1->host;

    if(length($host1) > 0) {
        $explicit{$host1} = 1;
    }
}
close XPLICIT;


if($opt{e}) {
    $str = do { local $/; <EVENTS> };
    eval { $events = $json->decode($str); };
    showRedirectionChain($events, $output_file_string);
print "call start\n";
findConnectedNodes(\%explicit, $events);
print "call end\n";
foreach my $key (keys %explicit) {
    print "key: " . $key . "\n";
}
    close EVENTS;

} elsif($opt{u}) {

    @urls=<URLS>;
    close URLS;

    ($elapsed, $events) = analyze_via_fireshark(\@urls);

    print "Elapsed time: " . $elapsed . "\n";

    my $buf;
    eval { $buf = $json->encode($events); };
    if($@) {

        print "error decoding json string: $!\n";

    } else {

        my $event_file = "events-" . $output_file_string . ".txt";
        open(EVENTS, ">$event_file") || die("Could not open file!");
        print EVENTS $buf;
        close EVENTS;
    }

print "call start\n";
findConnectedNodes(\%explicit, $events);
print "call end\n";
foreach my $key (keys %explicit) {
    print "key: " . $key . "\n";
}
    showRedirectionChain($events, $output_file_string);

    eval { $str = $json->encode($events); };
    if($@) {
        print "error encoding to json string: $!\n";
    }

} else {
    exit;
}

#######################################

sub findConnectedNodes {

    my ($explicit, $events) = @_;

    foreach my $event (@{$events}) {
        if(defined $event->{eventType} && $event->{eventType} eq "connection") {

            my $srchost = $event->{src};
	    my $dsthost = $event->{dst};

            if(($srchost !~ /^http:/) || ($dsthost !~ /^http:/)) {
	        next;
	    } 

	    my $u1 = URI->new($srchost);
 	    my $u2 = URI->new($dsthost);

	    my $host1 = $u1->host;
	    my $host2 = $u2->host;

            foreach my $key (keys %$explicit) {
  	        if(($host1 =~ /$key/) && not exists $explicit->{$host2}) {
                    $explicit->{$host2} = 1;
                    #findConnectedNodes($explicit, $events);
	        }
                     
  	        if(($host2 =~ /$key/) && not exists $explicit->{$host1}) {
                    $explicit->{$host1} = 1;
                    #findConnectedNodes($explicit, $events);
	        }   
            }
        }
    }
}

sub showRedirectionChain {

    my ($events, $output_file_string) = @_;

    my %loadurls;
    my %special;
    my %connections;
    my %nconns;
    my %dstrequestconns;
    my $g_iframes = {};

    my $g = GraphViz->new(bgcolor => 'black', overlap => 'false', layout => 'neato', width => 50, height => 50);

    foreach my $event (@{$events}) {
        if(defined $event->{eventType} && $event->{eventType} eq "connection") {

            my $srchost = $event->{src};
	    my $dsthost = $event->{dst};

            if(($srchost !~ /^http:/) || ($dsthost !~ /^http:/)) {
	        next;
	    } 

	    my $u1 = URI->new($srchost);
 	    my $u2 = URI->new($dsthost);

	    my $host1 = $u1->host;
	    my $host2 = $u2->host;

            if(($event->{type} eq "request")) {
                $dstrequestconns{$host2}++;
	    }

            if($host1 ne $host2) {
                $nconns{$host1}++;
	    }

            # regex check - used to mark particular nodes red
            # .exe is an example change accordingly
	    if($dsthost =~ /\.exe$/) {
	        $special{$host2} = $host2;
                print $dsthost . "\n";
	    } 

        }
    }

   #print "number of specified nodes found ",scalar keys %special,"\n";
   while ((my $key, my $value) = each %special)
   {
       print "$special{$key}\n";
   }

    foreach my $event (@{$events}) {


        if(defined $event->{eventType} && $event->{eventType} eq "loadurl") {

	    my $url = $event->{url};
	    my $u1 = URI->new($url);
	    my $host1 = $u1->host;

            $loadurls{$host1} = $host1;

            if($use_explicit) {
	        if($explicit{$host1}) {
	            $g->add_node($host1, shape => 'box', fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'yellow');
		}
	    } else {
	        $g->add_node($host1, shape => 'box', fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'yellow');
	    }
        }

        if(defined $event->{eventType} && $event->{eventType} eq "connection") {

            my $count = scalar keys %connections;
            if($count > 500) { 
  	        print "reached max connection limit for graphviz\n";
                last; 
	    } # to avoid graphviz running out of mem.

            my $srchost = $event->{src};
	    my $dsthost = $event->{dst};

	    my $u1 = URI->new($srchost);
 	    my $u2 = URI->new($dsthost);

	    my $host1 = $u1->host;
	    my $host2 = $u2->host;

            # add node for src
            if(not exists $loadurls{$host1}) {

		if(exists $special{$host1} ) {
                    if($use_explicit) {
	                if($explicit{$host1}) {
	                    $g->add_node($host1, fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'red');
			} 
		    } else {
	                $g->add_node($host1, fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'red');
		    }
   		} else {
                    if($use_explicit) {
	                if($explicit{$host1}) {
	                    $g->add_node($host1, fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'green');
			}
		    } else {
	                $g->add_node($host1, fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'green');
		    }
		}
	    } 
           
            # add node for dst 
            if(not exists $loadurls{$host2}) {

                my $width = 1;
                my $height = 1;
                if(exists $dstrequestconns{$host2}) {
                    my $size = $dstrequestconns{$host2};
                    if($size > 10) {
                        $width+=2;
                        $height+=2;
		    }
		}

		if(exists $special{$host2} ) {

                    if($use_explicit) {
	                if($explicit{$host2}) {
	                    $g->add_node($host2, width => $width, height => $height, fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'red');
			}
		    } else {
	                $g->add_node($host2, width => $width, height => $height, fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'red');

		    }

		} else {
                    if($use_explicit) {
	                if($explicit{$host2}) {

	                    $g->add_node($host2, width => $width, height => $height,fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'green');
			}
		    } else {

	                $g->add_node($host2, width => $width, height => $height,fontcolor => 'black', color => 'black', style => 'filled', fillcolor => 'green');

		    }
		}
	    } 

	    #if ($host1 ne $host2 and not exists $connections{$host1 . $host2}) {
	    if ($host1 ne $host2) {

                if(defined $g_iframes) {
                    if(defined $g_iframes->{$u2}) {

                        if($use_explicit) {
	                    if($explicit{$host1} && $explicit{$host2}) {
                                $g->add_edge($host1 => $host2, label => 'iframe', fontcolor => 'green', color => 'green');
			    }
			} else {
                            $g->add_edge($host1 => $host2, label => 'iframe', fontcolor => 'green', color => 'green');

			}

                    } elsif(defined $event->{type} and 
			    $event->{type} eq "response" and
			    defined $event->{status}) {

                        if($use_explicit) {
	                    if($explicit{$host1} && $explicit{$host2}) {
                                $g->add_edge($host1 => $host2, label => $event->{status}, fontcolor => 'green', color => 'green');
			    }
			} else {
                            $g->add_edge($host1 => $host2, label => $event->{status}, fontcolor => 'green', color => 'green');
			}

		    } else {

                        if($use_explicit) {
	                    if($explicit{$host1} && $explicit{$host2}) {
                                $g->add_edge($host1 => $host2, fontcolor => 'green', color => 'green');
			    }
		        } else {
                            $g->add_edge($host1 => $host2, fontcolor => 'green', color => 'green');
		        }
                    }
                } else {

                    if($use_explicit) {
	                if($explicit{$host1} && $explicit{$host2}) {
                            $g->add_edge($host1 => $host2, fontcolor => 'green', color => 'green');
			}
		    } else {
                        $g->add_edge($host1 => $host2, fontcolor => 'green', color => 'green');
		    }
                }
	    
                $connections{$host1 . $host2} = 1;

            }


	}
    }

    my $png_file = "graph-" . $output_file_string . ".png";
    $g->as_png($png_file); # save image

}

#!/usr/bin/perl -w

use Getopt::Std;

use warnings;
use strict;
use URI;
use IO::Socket;
use JSON::XS;
use MIME::Base64;
use GraphViz;
use Time::HiRes qw(time gettimeofday tv_interval);
use Data::Dump qw(dump);

#
# Globals
#
use vars qw/ %opt /;

my %nv;

sub IncrementNV
{
    my $n = shift;
    if($nv{$n})
    {
        $nv{$n}++;
    }
    else
    {
        $nv{$n} = 1;
    }
}

sub hashValueAscendingNum {
   $nv{$a} <=> $nv{$b};
}

sub hashValueDescendingNum {
    $nv{$b} <=> $nv{$a};
}

#
# Command line options processing
#
sub init()
{
    my $opt_string = 'hvde:';
    getopts( "$opt_string", \%opt ) or usage();
    if($opt{h} or !$opt{e})
    {
        usage();
    }
}

#
# Message about this program and how to use it
#
sub usage()
{
print STDERR << "EOF";

    This program will take an input file of event data and output
    a egress ingress information

    usage: $0 [-hvd] [-e file]

     -h        : this (help) message
     -v        : verbose output
     -d        : print debugging messages to stderr
     -e file   : event data input file 

    example: $0 -v -d -e file

EOF

    exit;
}

init();

print STDERR "Verbose mode ON.\n" if $opt{v};
print STDERR "Debugging mode ON.\n" if $opt{d};

my $event_input_file;

if($opt{e})
{
    $event_input_file = $opt{e}; 
    print "event input file = $event_input_file \n" if $opt{v} || $opt{d};
}
else
{
    exit;
}

if($opt{e})
{
    open EVENTS, "<", $event_input_file or die $!;
}

##############################################################

my $str;
my $events;
my @urls;
my $json = JSON::XS->new;

if($opt{e}) {
    $str = do { local $/; <EVENTS> };
    eval { $events = $json->decode($str); };
    egressIngress($events);
    close EVENTS;
} else {
    exit;
}

#######################################

sub egressIngress {

    my ($events) = @_;

    my %req_src;
    my %req_dst;
    my %resp_src;
    my %resp_dst;

    my %req_src_ex;
    my %req_dst_ex;
    my %resp_src_ex;
    my %resp_dst_ex;

    my %loadurls;

    foreach my $event (@{$events}) {

        if(defined $event->{eventType} && $event->{eventType} eq "loadurl") {

            my $url = $event->{url};
            my $u1 = URI->new($url);
            my $host1 = $u1->host;

            $loadurls{$host1} = $host1;
        }
    }

    foreach my $event (@{$events}) {
        if(defined $event->{eventType} && $event->{eventType} eq "connection") {

            my $srchost = $event->{src};
	    my $dsthost = $event->{dst};

	    my $u1 = URI->new($srchost);
 	    my $u2 = URI->new($dsthost);

            if(($srchost !~ /^http:/) || ($dsthost !~ /^http:/)) {
                next;
            }

	    my $host1 = $u1->host;
	    my $host2 = $u2->host;

            if($host1 ne $host2) {
                if(($event->{type} eq "request")) {
                    $req_src{$host1}++;
                    if(not exists $req_src_ex{$host1}) {
                        $req_src_ex{$host1} = $host2;
                    }
                    $req_dst{$host2}++;
                    if(not exists $req_dst_ex{$host2}) {
                        $req_dst_ex{$host2} = $host1;
                    }
		}
                elsif(($event->{type} eq "response")) {
                    $resp_src{$host1}++;
                    if(not exists $resp_src_ex{$host1}) {
                        $resp_src_ex{$host1} = $host2;
                    }
                    $resp_dst{$host2}++;
                    if(not exists $resp_dst_ex{$host2}) {
                        $resp_dst_ex{$host2} = $host1;
                    }
		}
	    }
        }
    }

   #
   # request
   #
   print "number of request src nodes ",scalar keys %req_src,"\n";
   foreach my $key (sort { $req_src{$b} <=> $req_src{$a} } keys %req_src) {

       print "$req_src{$key}\t$key e.g. $req_src_ex{$key}\n";
   }

   print "number of request dst nodes ",scalar keys %req_dst,"\n";
   foreach my $key (sort { $req_dst{$b} <=> $req_dst{$a} } keys %req_dst) {

       print "$req_dst{$key}\t$key e.g. $req_dst_ex{$key}\n";
   }

   # 
   # response
   #
   print "number of response src nodes ",scalar keys %resp_src,"\n";
   foreach my $key (sort { $resp_src{$b} <=> $resp_src{$a} } keys %resp_src) {

       print "$resp_src{$key}\t$key e.g. $resp_src_ex{$key}\n";
   }

   print "number of response dst nodes ",scalar keys %resp_dst,"\n";
   foreach my $key (sort { $resp_dst{$b} <=> $resp_dst{$a} } keys %resp_dst) {

       print "$resp_dst{$key}\t$key e.g. $resp_dst_ex{$key}\n";
   }
}

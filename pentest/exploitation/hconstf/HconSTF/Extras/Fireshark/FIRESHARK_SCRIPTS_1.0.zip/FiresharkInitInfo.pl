#!/usr/bin/perl

#
# requires yaml
# e.g sudo apt-get install libyasml-perl
# http://search.cpan.org/dist/YAML/
# http://en.wikipedia.org/wiki/YAML
#
use strict;
use warnings;

use YAML qw(LoadFile);
use URI;
use Data::Validate::URI qw(is_uri);
use Data::Dumper;
use Socket;
use Net::DNS;

my $DATA_FILE = 'reportlog.yml';
my $data = LoadFile($DATA_FILE) || croak ("failed to load data file '$DATA_FILE'");

#print Dumper($data), "\n";

my %start_nodes;
my %connected;
my %src_count;
my %dst_count;
my %iframe_count;

my $info;
my $hosts;
my @errors;

sub IncrementNV
{
    my ($hashref, $name) = @_;

    if($name eq '') { return; }
    if(exists $hashref->{$name})
    {
        $hashref->{$name}++;
    }
    else
    {
        $hashref->{$name} = 1;
    }
}

sub to_host {
    my $url = shift;
    if($url =~ /^(https?|ftp|file):\/\/.+$/) {
        my $u = URI->new($url);
        my $h = $u->host;
        return $h;
    } else {
        return '';
    }
}

sub store_host {
    my $url = shift;
    if($url =~ /^(https?|ftp|file):\/\/.+$/) {
        my $u = URI->new($url);
        my $h = $u->host;
        $hosts->{$h} = 1;
    } else {
        push(@errors, $url);
    }
}

sub to_info {

    # dump dst count
    open DSTCOUNT, ">", "dstcount.txt" or die $!;
    foreach my $key (sort {$dst_count{$b} <=> $dst_count{$a} } keys %dst_count) {
        print DSTCOUNT "$key\t$dst_count{$key}\n";
    }
    close DSTCOUNT;

    # dump src count
    open SRCCOUNT, ">", "srccount.txt" or die $!;
    foreach my $key (sort {$src_count{$b} <=> $src_count{$a} } keys %src_count) {
        print SRCCOUNT "$key\t$src_count{$key}\n";
    }
    close SRCCOUNT;

    # dump iframe count
    open IFRAMECOUNT, ">", "iframecount.txt" or die $!;
    foreach my $key (sort {$iframe_count{$b} <=> $iframe_count{$a} } keys %iframe_count) {
        print IFRAMECOUNT "$key\t$iframe_count{$key}\n";
    }
    close IFRAMECOUNT;

    # fetch ip information
    foreach my $key (keys %{$hosts}) {
        my $host = $key;
        $info->{$host}->{host} = $host;
        my $net = inet_aton($host);
        if ( not defined($net) ) {
            push(@errors, $host);
            next;
        }
        my $address = inet_ntoa(inet_aton($host));
        if ( not exists($info->{$host}->{ip}) ) {
            $info->{$host}->{ip} = $address;
        }
    }
   
    # log errors
    open ERRORS, ">", "errors.txt" or die $!;
    foreach my $error (@errors) {
        print ERRORS "$error\n";
    }
    close ERRORS;

    # log host + ips
    open HOSTIPS, ">", "hostips.txt" or die $!;
    foreach my $key (keys %{$info}) {
        if(exists($info->{$key}->{ip})) {
            print HOSTIPS "$key\t$info->{$key}->{ip}\n";
        }
    }
    close HOSTIPS;


    # log cymru ips for use in next block of code
    open IPS, ">", "cymru.txt" or die $!;
    print IPS "begin\nverbose\n";
    foreach my $key (keys %{$info}) {
        if(exists($info->{$key}->{ip})) {
            print IPS "$info->{$key}->{ip}\n";
        }
    }
    print IPS "end\n";
    close IPS;

    #first line is:
    # whois.cymru.com [2010-02-07 00:11:08 +0000]
    # then each preceeding line loks like:
    # 4837| 60.28.188.142 | 60.28.0.0/15 | CN | apnic | 2004-04-16 | CHINA169-BACKBONE CNCGROUP China169 Backbone
    # http://www.team-cymru.org/Services/ip-to-asn.html

    my $cymru_info;
    my $result = `netcat whois.cymru.com 43 < cymru.txt`;
    my @cmyru_results = split(/\n/, $result);
    for(my $i=0; $i<scalar(@cmyru_results); $i++) {

        # skip first line of cymru output it's a header
        if($i == 0) { next; }

        my $cymru_result = $cmyru_results[$i];
        my @fields = split(/\|/, $cymru_result);
        for(my $j=0; $j<scalar(@fields); $j++) {
            $fields[$j] =~ s/ //g;
        }

        my $ip = $fields[1];
        $cymru_info->{$ip}->{as} = $fields[0];
        $cymru_info->{$ip}->{bgp_prefix} = $fields[2];
        $cymru_info->{$ip}->{cc} = $fields[3];
        $cymru_info->{$ip}->{registry} = $fields[4];
        $cymru_info->{$ip}->{allocated} = $fields[5];
        $cymru_info->{$ip}->{as_name} = $fields[6];
    }

    # HOST     | AS  | IP            | BGB PREFIX   | CC | REG   | ALLOC.     | AS NAME
    # # test.com |4837| 60.28.188.142 | 60.28.0.0/15 | CN | apnic | 2004-04-16 | CHINA169-BACKBONE CNCGROUP China169 Backbone

    open INFO, ">", "info.txt" or die $!;
    foreach my $key (keys %{$info}) {
        my $host = $key;
        my $ip = $info->{$key}->{ip};

            print INFO $host, " | ";
        (defined($ip) && exists($cymru_info->{$ip}) ? 
		print INFO $cymru_info->{$ip}->{as}, " | " : print INFO " | ");
        (defined($host) && exists($info->{$host}) && exists($info->{$host}->{ip}) ? 
		print INFO $info->{$host}->{ip}, " | " : print INFO " | ");
        (defined($ip) && exists($cymru_info->{$ip}) && exists($cymru_info->{$ip}->{bgp_prefix}) ? 
		print INFO $cymru_info->{$ip}->{bgp_prefix}, " | " : print INFO " | ");
        (defined($ip) && exists($cymru_info->{$ip}) && exists($cymru_info->{$ip}->{cc}) ? 
		print INFO $cymru_info->{$ip}->{cc}, " | " : print INFO " | ");
        (defined($ip) && exists($cymru_info->{$ip}) && exists($cymru_info->{$ip}->{registry}) ? 
		print INFO $cymru_info->{$ip}->{registry}, " | " : print INFO " | ");
        (defined($ip) && exists($cymru_info->{$ip}) && exists($cymru_info->{$ip}->{allocated}) ? 
		print INFO $cymru_info->{$ip}->{allocated}, " | " : print INFO " | ");
        (defined($ip) && exists($cymru_info->{$ip}) && exists($cymru_info->{$ip}->{as_name}) ? 
		print INFO $cymru_info->{$ip}->{as_name}, " | " : print INFO " | ");
    }

    close INFO;
}

if ( ref($data) eq 'HASH' ) {
    my $events = $data->{events};
    if ( ref($events) eq 'ARRAY' ) {
        foreach my $event ( @$events ) {
            if ( ref($event) eq 'HASH' ) {
                # urlloaded events
                if ( exists( $event->{urlloaded} ) ) {
                    if ( exists( $event->{urlloaded}->{url} ) ) {
		        my $url = $event->{urlloaded}->{url};
			store_host($url);
			my $h = to_host($url);
			$start_nodes{ $h } = 1;
		    }
		}
                # contentloaded events
                elsif ( exists( $event->{contentloaded} ) ) {
                    if ( exists( $event->{contentloaded}->{url} ) ) {
		        my $url = $event->{contentloaded}->{url};
			store_host($url);
		    }
                    if ( exists( $event->{contentloaded}->{frames} ) ) {
		        my $frames = $event->{contentloaded}->{frames};
                        if ( ref($frames) eq 'ARRAY' ) {
                            foreach my $frame ( @$frames ) {
                                if ( exists( $frame->{frame}->{url} ) ) {
 				    my $url = $frame->{frame}->{url};
			            store_host($url);
			            my $h = to_host($url);
                                    IncrementNV(\%iframe_count, $h);
				}
                                if ( exists( $frame->{frame}->{parenturl} ) ) {
 				    my $parenturl = $frame->{frame}->{parenturl};
			            store_host($parenturl);
				}
			    }
			}
		    }
                    if ( exists( $event->{contentloaded}->{iframes} ) ) {
		        my $iframes = $event->{contentloaded}->{iframes};
                        if ( ref($iframes) eq 'ARRAY' ) {
                            foreach my $iframe ( @$iframes ) {
                                if ( exists( $iframe->{iframe}->{url} ) ) {
 				    my $url = $iframe->{iframe}->{url};
			            store_host($url);
				}
			    }
			}
		    }
		}
                # connection events
                elsif ( exists( $event->{connection} ) ) {
                    if ( exists( $event->{connection}->{src} ) ) {
		        my $src = $event->{connection}->{src};
			store_host($src);
		    }
                    if ( exists( $event->{connection}->{dst} ) ) {
		        my $dst = $event->{connection}->{dst};
			store_host($dst);
		    }

                    if( exists( $event->{connection}->{dst} ) &&
		        exists( $event->{connection}->{src} ) &&
                        exists( $event->{connection}->{type} )) {
                        my $type = $event->{connection}->{type};
			my $src = to_host($event->{connection}->{src});
			my $dst = to_host($event->{connection}->{dst});

                        if ( not exists ( $connected{ $src . $dst }) ) {
                            if( not exists ( $start_nodes{ $src } ) ) {
                                IncrementNV(\%src_count, $src);
                            }
                            
                            if( not exists ( $start_nodes{ $dst } ) ) {
                                IncrementNV(\%dst_count, $dst);
 			    }

		            $connected{ $src . $dst } = 1;
                        }

		    }
		}
	    }
        }
   }
}

to_info();


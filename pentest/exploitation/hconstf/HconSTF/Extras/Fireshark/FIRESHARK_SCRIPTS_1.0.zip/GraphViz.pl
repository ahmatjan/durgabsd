#!/usr/bin/perl

#
# requires yaml
# e.g sudo apt-get install libyasml-perl
# http://search.cpan.org/dist/YAML/
# http://en.wikipedia.org/wiki/YAML
#

use strict;
use warnings;

use YAML qw(LoadFile);
use GraphViz;
use URI;
use Data::Validate::URI qw(is_uri);

use Data::Dumper;

my $IMAGE_FILE = 'report.png';
my $HTML_FILE = 'report.html';
my $DATA_FILE = 'reportlog.yml';

my $data = LoadFile($DATA_FILE) || croak ("failed to load data file '$DATA_FILE'");

open HTML, ">", $HTML_FILE or die $!;
print HTML "<html><body>";

#print Dumper($data), "\n";

my $db;
sub build_db {

    open DB, "<", "info.txt" or die $!;
    my @lines = <DB>;
    foreach my $line (@lines) {
        chomp($line);
        my @fields = split(/\|/, $line);
        for(my $i=0; $i<scalar(@fields); $i++) {
            # strip space from beginning and end
            $fields[$i] =~ s/^\s+//g;
            $fields[$i] =~ s/\s+$//;
	}
#
# HOST     | AS  | IP            | BGB PREFIX   | CC | REG   | ALLOC.     | AS NAME
# test.com | 4837| 60.28.188.142 | 60.28.0.0/15 | CN | apnic | 2004-04-16 | CHINA169-BACKBONE CNCGROUP China169 Backbone
#
    
         my $host = $fields[0];
        $db->{$host}->{host} = $fields[0];
        $db->{$host}->{as} = $fields[1];
        $db->{$host}->{ip} = $fields[2];
        $db->{$host}->{bgp_prefix} = $fields[3];
        $db->{$host}->{cc} = $fields[4];
        $db->{$host}->{registry} = $fields[5];
        $db->{$host}->{allocated} = $fields[6];
        $db->{$host}->{as_name} = $fields[7];
    }

    close DB;
}

sub to_host {
    my $url = shift;
    if($url =~ /^(https?|ftp|file):\/\/.+$/) {
        my $u = URI->new($url);
        my $h = $u->host;
        return $h;
    } else {
        return '';
    }
}

sub to_label {

    my $host = shift;
    if( exists($db->{$host}) ) {
        if(exists $db->{$host}->{host}) {
            return $db->{$host}->{host};
        } else {
            print "$host not found\n";
            return '';
        }
    } else {
        return '';
    }
}

build_db();

my $g = GraphViz->new(overlap => 'false', layout => 'neato');
#my $g = GraphViz->new(overlap => 'scalexy', layout => 'neato');
#my $g = GraphViz->new(layout => 'neato');

my $node_fillcolor = 'lightgray';
my $node_fontcolor = 'black';

my %start_nodes;
my %connected;
my %iframes;

my @connection_events;

if ( ref($data) eq 'HASH' ) {
    my $events = $data->{events};
    if ( ref($events) eq 'ARRAY' ) {
        foreach my $event ( @$events ) {
            if ( ref($event) eq 'HASH' ) {
                # urlloaded events
                if ( exists( $event->{urlloaded} ) ) {
                    if ( exists( $event->{urlloaded}->{url} ) ) {
		        my $url = $event->{urlloaded}->{url};
                        my $host = to_host($url);
                        if ( $host ne '' ) {
                            print $url, " is a start node\n";
			    $start_nodes{ $host } = 1;

			    $node_fillcolor = 'lightblue';
			    $g->add_node($host, style => 'filled', fontcolor => $node_fontcolor, color => $node_fillcolor);
			} 
		    }
		}
                # contentloaded events
                elsif ( exists( $event->{contentloaded} ) ) {

                    print HTML "<p>";

                    if ( exists( $event->{contentloaded}->{url} ) ) {
		        my $url = $event->{contentloaded}->{url};
                        print $url, " content has loaded\n";
                        print HTML "url: " . $url . "<br />\n";
		    }
                    if ( exists( $event->{contentloaded}->{srcfile} ) ) {
		        my $srcfile = $event->{contentloaded}->{srcfile};
                        print HTML "<a href=\"" . $srcfile . "\">SRC</a><br />\n";
		    }
                    if ( exists( $event->{contentloaded}->{parentDOM} ) ) {
                        if ( exists( $event->{contentloaded}->{parentDOM}->{url} ) &&
			     exists( $event->{contentloaded}->{parentDOM}->{file} ) ) {
		            my $url = $event->{contentloaded}->{parentDOM}->{url};
		            my $file = $event->{contentloaded}->{parentDOM}->{file};
			    print HTML "<a href=\"" . $file . "\">PARENT DOM " . $url . "</a><br />\n";
		        }
		    }
 		    if ( exists( $event->{contentloaded}->{doms} ) ) {
		        my $doms = $event->{contentloaded}->{doms};
			if ( ref($doms) eq 'ARRAY' ) {
                            foreach my $dom ( @$doms ) {
                                if ( exists( $dom->{dom}->{url} ) &&
				     exists( $dom->{dom}->{file} ) ) {
 				    my $url = $dom->{dom}->{url};
 				    my $file = $dom->{dom}->{file};
				    print HTML "<a href=\"" . $file . "\">DOM " . $url . "</a><br />\n";
				}
			    }
		        }
		    }
                    if ( exists( $event->{contentloaded}->{screenshot} ) ) {
		        my $ss = $event->{contentloaded}->{screenshot};
			print HTML "<a href=\"" . $ss . "\"" . "<img width=\"400\" src=\"" . $ss . "\" /></a><br />\n";
		    }
                    if ( exists( $event->{contentloaded}->{frames} ) ) {
		        my $frames = $event->{contentloaded}->{frames};
                        print "FRAMES EXIST\n";
                        if ( ref($frames) eq 'ARRAY' ) {
                            foreach my $frame ( @$frames ) {
                                if ( exists( $frame->{frame}->{name} ) &&
				     exists( $frame->{frame}->{url} ) &&
				     exists( $frame->{frame}->{parenturl} ) ) {
 				    my $name = $frame->{frame}->{name};
 				    my $url = $frame->{frame}->{url};
 				    my $parenturl = $frame->{frame}->{parenturl};
				    print "FRAME ", $url, $name, " \n";
				    if($url ne "about:blank" && $parenturl ne "about:blank") {
                                        my $host = to_host($url);
                                        my $parenthost = to_host($parenturl);
                                        if ( $host eq '' || $parenthost eq '' ) { next; }
				        if ( $name eq "IFRAME" ) {
                                            print "iframe connection from ", $parenthost, " -> ", $host, "\n";
                                            $iframes{ $parenthost . $host } = 1;
				        }
                                    }
				}
			    }
			}
		    }
                    if ( exists( $event->{contentloaded}->{iframes} ) ) {
		        my $iframes = $event->{contentloaded}->{iframes};
                        if ( ref($iframes) eq 'ARRAY' ) {
                            foreach my $iframe ( @$iframes ) {
                                if ( exists( $iframe->{iframe}->{url} ) ) {
 				    my $url = $iframe->{iframe}->{url};
				}
			    }
			}
		    }

                    print HTML "</p>";
		}
                # connection events
                elsif ( exists( $event->{connection} ) ) {
		    push(@connection_events, $event);
		}
	    }
        }
   }
}

# now that information has been gathered from the content loaded events
# loop through the saved connection events and graph nodes and edges
print "connection events\n";
foreach my $event (@connection_events) {
    if ( exists( $event->{connection}->{type} ) &&
	 exists( $event->{connection}->{src} ) &&
	 exists( $event->{connection}->{dst} ) ) {

        my $type = $event->{connection}->{type};
        my $src = $event->{connection}->{src};
        my $dst = $event->{connection}->{dst};
        my $status = $event->{connection}->{status};

	$src = to_host($src);
	$dst = to_host($dst);

        if ( $src eq '' || $dst eq '' ) { next; }
			
	print $type, " ", $src, "->", $dst, "\n";

	# add src node
	if ( not exists $start_nodes{ $src } ) {
	     
             $node_fillcolor = 'lightgray';
             $node_fontcolor = 'black';

             $g->add_node($src, style => 'filled', fontcolor => $node_fontcolor, color => $node_fillcolor);
	}

	# add dst node
	if ( not exists $start_nodes{ $dst } ) {
	     
             $node_fillcolor = 'lightgray';
             $node_fontcolor = 'black';
	     

             $g->add_node($dst, style => 'filled', fontcolor => $node_fontcolor, color => $node_fillcolor);
        }

	# add edge
	my $edge_color = "black";
        if($type eq "request") {
            $edge_color = "green";
        } 
	elsif($type eq "response") {
            $edge_color = "blue";
        }

	if (not exists $connected{ $src . $dst } ) {
            if (exists $iframes{ $src . $dst } && $type eq "request") {
                $g->add_edge($src => $dst, label => 'iframe', color => $edge_color);
            }
	    elsif (defined $status) {
                $g->add_edge($src => $dst, label => $status, color => $edge_color);
            }
            else {
                $g->add_edge($src => $dst, color => $edge_color);
            }

            $connected{ $src . $dst } = 1;
	}
    }
}


print $g->as_png($IMAGE_FILE);
print HTML "</body></html>";
close HTML;


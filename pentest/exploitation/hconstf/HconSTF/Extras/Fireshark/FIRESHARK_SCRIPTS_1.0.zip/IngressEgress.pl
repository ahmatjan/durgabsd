#!/usr/bin/perl

# http://www.gnuplot.info/docs_4.4/gnuplot.pdf
#
use strict;
use warnings;

my $srcfile = "srccount.txt";
my $dstfile = "dstcount.txt";

# dst nodes
# PNG
open (GNUPLOT, "|gnuplot");
print GNUPLOT <<EOPLOT;
set term png size 15000,800
set output "$srcfile.png"
unset key
unset grid
set style data linespoints 
set title "Unique Host Egress Connections Frequency"
set ylabel "No. Egress Connections"
set xlabel "Unique Host"
set xtics  nomirror rotate by 90 
plot "$srcfile" using 2:xtic(1) with points pointsize 1 linewidth 2
EOPLOT
close(GNUPLOT);

# src nodes
# PNG
open (GNUPLOT, "|gnuplot");
print GNUPLOT <<EOPLOT;
set term png size 15000,800
set output "$dstfile.png"
unset key
unset grid
set style data linespoints 
set title "Unique Host Ingress Connections Frequency"
set ylabel "No. Ingress Connections"
set xlabel "Unique Host"
set xtics  nomirror rotate by 90 
plot "$dstfile" using 2:xtic(1) with points pointsize 1 linewidth 2
EOPLOT
close(GNUPLOT);

#set xtics rotate by 90 
#set style data histogram
#set boxwidth 0.1
#plot "$file" using 2:xtic(1) with points pointsize 1 linewidth 1
#plot "$file" using 2:xtic(1)
#set xrange [0:1000]
#plot "$file" using 3:4:xticlabels(1) with linespoints
#set term png small xFFFFFF
#set yrange [0:10]
#set ytics nomirror
